/**
 * 
 */
package tamago.csp.binarytree;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JComponent;
import javax.swing.JPanel;


class BTreeDrawNodePanel extends JComponent {

	private ArrayList<BTreeDrawNode> nodes;
	/**
	 * 
	 */
	private static final long serialVersionUID = 7860073289065041692L;
	
	public BTreeDrawNodePanel() {
		nodes = new ArrayList<BTreeDrawNode>();
	}
	
	public void add(BTreeDrawNode node) {
		nodes.add(node);
	}
	
	@Override
	public void paint(Graphics g) {
		for (BTreeDrawNode node : nodes) {
			node.paint(g);
		}
	}
	
}

/**
 * @author Hakim Belhaouari
 *
 */
public class BTreeDrawNode {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4556597117536042689L;
	private BTreeConstant constant;
	private int x;
	private int y;
	private int w;
	private int h;
	private int lx;
	private int ly;
	private int rx;
	private int ry;
	private String name;
	
	/**
	 * 
	 */
	public BTreeDrawNode(String name,int x, int y, int w, int h, int lx, int ly, int rx, int ry, BTreeConstant constant) {
		this.constant = constant;
		this.name = name;
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.lx = lx;
		this.ly = ly;
		this.rx = rx;
		this.ry = ry;
	}

	public void paint(Graphics g) {
		g.setColor(Color.BLACK);
		if(constant.hasLeft()) {
			g.drawLine(x, y+h, lx, ly);
		}
		
		if(constant.hasRight()) {
			g.drawLine(x+w, y+h, rx, ry);
		}
		
		g.setColor(Color.CYAN);
		g.fillRect(x, y, w, h);
		g.setColor(Color.BLACK);
		g.setFont( new Font("Helvetica", Font.BOLD, 14)  );
		g.drawString(name, x, y);
		if(constant.isNull()) {
			g.setColor(Color.RED);
			g.drawString("X", x, y+ h/2);
		}
		else {
			g.setColor(Color.RED);
			g.drawString("D:"+constant.owner().depth().getValue().intValue(), x, y+ h/2);
			g.drawString("S:"+constant.owner().size().getValue().intValue(), x, y+ h);
		}
		
	}
}

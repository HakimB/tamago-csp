/**
 * 
 */
package tamago.csp.binarytree;

import java.util.ArrayList;

import tamago.csp.constant.CSPinteger;
import tamago.csp.exception.TamagoCSPException;
import tamago.csp.generic.CSPConstraint;
import tamago.csp.generic.CSPvar;
import tamago.csp.var.Intvar;

/**
 * @author Hakim Belhaouari
 *
 */
public class BTreeMaxDepthConstraint implements CSPConstraint {

	private BTreeNode node;
	private ArrayList<CSPvar> var;
	private boolean filtering;
	
	/**
	 * 
	 */
	public BTreeMaxDepthConstraint(BTreeNode node) {
		this.node = node;
		filtering = false;
		node.install(this);
		node.depth().install(this);
		node.size().install(this);
		node.me().install(this);
	}

	/**
	 * @see tamago.csp.generic.CSPConstraint#filter()
	 */
	@Override
	public void filter() throws TamagoCSPException {
		if(filtering)
			return;
		try {
			filtering = true;
			
			if(node.size().isFixed()) {
				if(node.size().getValue().intValue() > 0)
					node.me().fix(new CSPinteger(1));
				else
					node.me().fix(new CSPinteger(0));
			}
			
			if(node.depth().isFixed()) {
				if(node.depth().getValue().intValue() > 0)
					node.me().fix(new CSPinteger(1));
				else
					node.me().fix(new CSPinteger(0));
			}
			
			if(node.me().isInDomain(new CSPinteger(1))) {
				int max = node.depth().getMax().intValue() - 1;
				node.depthG().setMax(new CSPinteger(max));
				node.depthD().setMax(new CSPinteger(max));

				int maxG = node.depthG().getMax().intValue() + 1;
				int maxD = node.depthD().getMax().intValue() + 1;
				node.depth().setMax(new CSPinteger(Math.max(maxG, maxD)));
			}
			else {
				node.depth().fix(new CSPinteger(0));
				node.depthG().fix(new CSPinteger(0));
				node.depthD().fix(new CSPinteger(0));
				node.size().fix(new CSPinteger(0));
			}
		}
		finally {
			filtering = false;
		}
		
		

	}

	/**
	 * @see tamago.csp.generic.CSPConstraint#getVariables()
	 */
	@Override
	public Iterable<CSPvar> getVariables() {
		if(var == null)
			rawVars();
		return var;
	}

	
	
	
	private void rawVars() {
		var = new ArrayList<CSPvar>(1);
		var.add(node);
	}

	/**
	 * @see tamago.csp.generic.CSPConstraint#size()
	 */
	@Override
	public int size() {
		return 1;
	}

}
